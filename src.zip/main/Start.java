package main;

public class Start {
	public static void main(String[] args) throws Exception { 
		new App().run();
	}
}