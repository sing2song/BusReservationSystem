package main;

public class test {

	public static void main(String[] args) {
		System.out.println("되나?");
		
		System.out.println("되라");
		
		System.out.println("push 체크");
	}
}
